import numpy as np


def vaccinate(day):
    day = day.isoformat()
    if day > '2021-01-01':
        # return np.array([0, 0, 0, 0, 0, 0, 120, 120, 120, 120])
        return np.ones((10)) * 10000
    else:
        return 0
